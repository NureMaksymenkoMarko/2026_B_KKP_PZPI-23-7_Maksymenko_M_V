import 'package:flutter_test/flutter_test.dart';

enum UserRole { student, teacher, moderator }

String homeFor(UserRole? role) {
  switch (role) {
    case UserRole.student:
      return '/student/home';
    case UserRole.teacher:
      return '/teacher/home';
    case UserRole.moderator:
      return '/admin/home';
    case null:
      return '/login';
  }
}

bool canOpenRoute(UserRole role, String route) {
  if (route.startsWith('/student/')) return role == UserRole.student;
  if (route.startsWith('/teacher/')) return role == UserRole.teacher;
  if (route.startsWith('/admin/')) return role == UserRole.moderator;
  return true;
}

void main() {
  group('Role routing', () {
    test('student opens student home', () {
      expect(homeFor(UserRole.student), '/student/home');
      expect(canOpenRoute(UserRole.student, '/student/courses'), isTrue);
    });

    test('teacher cannot open admin route', () {
      expect(canOpenRoute(UserRole.teacher, '/admin/users'), isFalse);
    });

    test('moderator opens admin dashboard', () {
      expect(homeFor(UserRole.moderator), '/admin/home');
      expect(canOpenRoute(UserRole.moderator, '/admin/users'), isTrue);
    });
  });
}
