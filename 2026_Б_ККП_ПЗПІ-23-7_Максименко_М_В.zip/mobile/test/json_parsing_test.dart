import 'package:flutter_test/flutter_test.dart';

int parseInt(dynamic value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  if (value is String) return int.parse(value);
  throw FormatException('Unsupported integer value: $value');
}

DateTime parseDate(dynamic value) {
  if (value is DateTime) return value;
  if (value is String) return DateTime.parse(value);
  throw FormatException('Unsupported date value: $value');
}

void main() {
  group('JSON parsing helpers', () {
    test('parses numeric ids from int, double and string', () {
      expect(parseInt(10), 10);
      expect(parseInt(10.0), 10);
      expect(parseInt('10'), 10);
    });

    test('parses ISO date from API response', () {
      final parsed = parseDate('2026-05-02T08:55:00Z');
      expect(parsed.year, 2026);
      expect(parsed.month, 5);
      expect(parsed.day, 2);
    });
  });
}
