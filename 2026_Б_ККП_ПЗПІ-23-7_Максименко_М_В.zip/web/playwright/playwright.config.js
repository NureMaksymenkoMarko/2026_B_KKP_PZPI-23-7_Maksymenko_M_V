const { defineConfig } = require('@playwright/test');

module.exports = defineConfig({
  testDir: './',
  timeout: 30000,
  use: {
    headless: true,
    viewport: { width: 1440, height: 900 },
  },
});
