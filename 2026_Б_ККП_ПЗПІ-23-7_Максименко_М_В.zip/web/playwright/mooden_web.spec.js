// Playwright smoke tests for Mooden web pages.
// Before running, set BASE_URL, for example:
// BASE_URL=http://localhost:3000 npx playwright test web/playwright/mooden_web.spec.js

const { test, expect } = require('@playwright/test');

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';

const pages = [
  { path: '/login', text: /login|увійти|sign in/i },
  { path: '/student', text: /course|курс|assignments|завдання/i },
  { path: '/teacher', text: /teacher|викладач|course|курс/i },
  { path: '/admin/users', text: /users|користувач/i },
  { path: '/admin/reports', text: /reports|звіти/i },
];

for (const pageInfo of pages) {
  test(`page ${pageInfo.path} loads`, async ({ page }) => {
    await page.goto(`${BASE_URL}${pageInfo.path}`);
    await expect(page.locator('body')).toContainText(pageInfo.text);
  });
}

test('static resources do not return 404', async ({ page }) => {
  const badResponses = [];
  page.on('response', (response) => {
    const url = response.url();
    if ((url.includes('.js') || url.includes('.css') || url.includes('/assets/')) && response.status() >= 400) {
      badResponses.push(`${response.status()} ${url}`);
    }
  });
  await page.goto(`${BASE_URL}/login`);
  expect(badResponses).toEqual([]);
});
