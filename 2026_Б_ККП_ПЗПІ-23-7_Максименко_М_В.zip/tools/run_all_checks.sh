#!/usr/bin/env bash
set -e

echo "Mooden testing package"

if [ -d "mobile" ]; then
  echo "1) Flutter tests"
  (cd mobile && flutter test test/user_role_test.dart && flutter test test/json_parsing_test.dart && flutter test integration_test/mooden_smoke_test.dart)
else
  echo "mobile folder not found, skip Flutter tests"
fi

echo "2) API audit"
(cd tools && python3 endpoint_audit.py)

if [ -d "web/playwright" ]; then
  echo "3) Playwright tests"
  (cd web/playwright && npx playwright test)
else
  echo "web/playwright folder not found, skip Playwright"
fi
