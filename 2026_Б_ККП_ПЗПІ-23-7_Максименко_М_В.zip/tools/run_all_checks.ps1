# Run from the repository root after copying this testing package.
Write-Host "Mooden testing package" -ForegroundColor Cyan

Write-Host "1) Flutter tests"
if (Test-Path "mobile") {
  Push-Location mobile
  flutter test test/user_role_test.dart
  flutter test test/json_parsing_test.dart
  flutter test integration_test/mooden_smoke_test.dart
  Pop-Location
} else {
  Write-Host "mobile folder not found, skip Flutter tests" -ForegroundColor Yellow
}

Write-Host "2) API audit"
Push-Location tools
python endpoint_audit.py
Pop-Location

Write-Host "3) Playwright tests"
if (Test-Path "web/playwright") {
  Push-Location web/playwright
  npx playwright test
  Pop-Location
} else {
  Write-Host "web/playwright folder not found, skip Playwright" -ForegroundColor Yellow
}
