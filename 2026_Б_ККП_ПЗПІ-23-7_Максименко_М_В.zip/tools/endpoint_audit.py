#!/usr/bin/env python3
"""
Endpoint audit for Mooden.
Compares frontend/mobile API route manifests with backend route manifest.
Can be used as a standalone audit script for the KKP testing package.
"""

import argparse
import csv
import json
from pathlib import Path


def load_routes(path: Path):
    data = json.loads(path.read_text(encoding='utf-8'))
    return {(item['method'].upper(), item['path']) for item in data}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mobile', default='route_manifest_mobile.json', help='mobile route manifest JSON')
    parser.add_argument('--web', default='route_manifest_web.json', help='web route manifest JSON')
    parser.add_argument('--backend', default='backend_routes.json', help='backend route manifest JSON')
    parser.add_argument('--out', default='../test-results/api_audit_results.csv', help='CSV output path')
    args = parser.parse_args()

    root = Path(__file__).resolve().parent
    mobile = load_routes(root / args.mobile)
    web = load_routes(root / args.web)
    backend = load_routes(root / args.backend)

    frontend = sorted(mobile | web)
    rows = []
    mismatches = []
    for method, path in frontend:
        status = 'PASS' if (method, path) in backend else 'MISMATCH'
        if status != 'PASS':
            mismatches.append((method, path))
        rows.append({'method': method, 'path': path, 'source': 'mobile/web', 'status': status})

    out_path = (root / args.out).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['method', 'path', 'source', 'status'], delimiter=';')
        writer.writeheader()
        writer.writerows(rows)

    print(f'Checked frontend routes: {len(frontend)}')
    print(f'Backend routes: {len(backend)}')
    print(f'Mismatches: {len(mismatches)}')
    print(f'Result: {"PASS" if not mismatches else "FAIL"}')
    print(f'CSV saved to: {out_path}')
    return 1 if mismatches else 0


if __name__ == '__main__':
    raise SystemExit(main())
