# Mooden testing artifacts

Комплект файлів для тестування ККП: **«Освітня платформа для організації віртуального навчального процесу. Функціональне тестування мобільного та вебзастосунку»**.

## Що входить

- `test-cases/mobile_functional_test_cases.csv` — 35 функціональних тест-кейсів мобільної частини.
- `test-cases/web_functional_test_cases.csv` — 43 функціональні тест-кейси вебчастини.
- `test-results/mobile_test_results.csv` — таблиця результатів мобільного тестування.
- `test-results/web_test_results.csv` — таблиця результатів вебтестування.
- `test-results/api_audit_results.csv` — результати перевірки відповідності API-запитів backend-маршрутам.
- `mobile/test/user_role_test.dart` — unit-тест рольової логіки.
- `mobile/test/json_parsing_test.dart` — unit-тест парсингу JSON-даних.
- `mobile/integration_test/mooden_smoke_test.dart` — smoke-тест екрана входу.
- `web/playwright/mooden_web.spec.js` — приклад Playwright-перевірок вебсторінок.
- `tools/endpoint_audit.py` — Python-скрипт аудиту відповідності API.
- `tools/run_all_checks.ps1` та `tools/run_all_checks.sh` — команди запуску перевірок.

## Як запускати

### API audit

```bash
cd tools
python endpoint_audit.py
```

### Flutter tests

```bash
cd mobile
flutter test test/user_role_test.dart
flutter test test/json_parsing_test.dart
flutter test integration_test/mooden_smoke_test.dart
```

### Playwright

```bash
cd web/playwright
npm install @playwright/test
npx playwright test
```

## Призначення

Ці файли можна додати до GitHub-репозиторію як підтвердження виконання індивідуальної частини: функціональне тестування, тест-кейси, таблиці результатів, API audit і приклади автоматизованих перевірок.
